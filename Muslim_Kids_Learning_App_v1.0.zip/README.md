Muslim Kids Learning App - v1.0 (Bilingual: Urdu + English)

یہ ایک lightweight Flutter skeleton ہے تاکہ آپ فوراً GitHub پر upload کر کے
GitHub Actions سے APK build کروا سکیں.

Instructions:
1. Push this repository to GitHub.
2. Ensure your repo is public or set PAT if private.
3. GitHub Actions workflow will run `flutter create .` (to generate android/ folder) and then build the apk.
4. After action completes, download artifact from Actions -> latest run -> Artifacts.
